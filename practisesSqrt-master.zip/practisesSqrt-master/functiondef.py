

''' this is a quick note on functions,
this finds if the number is even or not, simple.
this is a docstring
'''

#def is keyword
#is_even is name
#i is parameter or argument

'''

first = input("input something")
print (first)

'''

def is_even (i):
	"""
	input is i, a positive integer
	returns True is i is even, otherwise False
	"""
	#body of function
	print ("hi")
	if i%2 == 0:
		print ("True")
	else:
		print ("False")
		return

i = int(input("type a number"))
is_even(i)

'''
def f(x):
	x = x + 1
	print("f(x) =", x)
	return x

x= 3
z = f(x)

'''
